# Zillow Analytics Engineering: Python · DuckDB · dbt · Power BI

End-to-end ELT pipeline that tracks US for-sale listings **over time**: daily snapshots from the
Zillow API (RapidAPI) are landed as raw JSON, modelled with dbt into a Kimball star schema, and
analysed in Power BI (price cuts, valuation gaps, time to first price cut, price-to-income).

> Educational project. Data from the unofficial Zillow® API via RapidAPI.

## Architecture

```
RapidAPI ──► Python ingestion ──► data/landing/*.json (immutable raw files)
                    │
                    ▼
            DuckDB / MotherDuck  raw.zillow_listings  (zpid, extracted_at, run_id, payload JSON)
                    │
                    ▼  dbt
   staging ──► intermediate ──► marts (dims + facts) ──► Power BI
```

## Data model

| Model | Layer | Grain |
|---|---|---|
| `stg_zillow__listing_snapshots` | staging | listing × extraction run (parsed JSON) |
| `stg_zillow__legacy_listing_snapshots` | staging | listing × extraction run (frozen v1 data) |
| `stg_census__zip_income` | staging | zip code |
| `int_listing_snapshots__unioned` | intermediate | listing × run, v1 + v2 |
| `int_listing_snapshots__validated` | intermediate | listing × run + quality flags |
| `int_listing_price_history` | intermediate | listing × run + previous snapshot (lag) |
| `int_zip_codes__resolved` | intermediate | zip code |
| `dim_dates` / `dim_locations` / `dim_properties` | marts | day / zip / listing (SCD1) |
| `fct_listing_snapshots` | marts | listing × run (periodic snapshot, incremental) |
| `fct_listing_lifecycle` | marts | listing (accumulating snapshot) |

## Design decisions

- **Raw JSON landing (ELT).** Python only moves data; dbt owns its meaning. The API can add or
  drop fields without breaking the load (fixes schema drift).
- **Idempotent loads.** Primary key `(zpid, extracted_at)` + `INSERT OR IGNORE`.
- **Replayable.** Every API response is saved to `data/landing/`; `--replay` rebuilds the warehouse
  without spending API quota.
- **Flag, don't filter.** Invalid rows are kept with `is_valid_listing = false`, so data quality is
  measurable.
- **SCD Type 1 for properties.** Physical attributes are treated as non-changing; latest wins.
- **Legacy migration.** v1 flattened data was kept as a frozen source and unioned by name, so no
  history was lost (`source_system` column).

## Known limitations

- `approx_median_household_income` averages census-tract medians; it is not a true zip median.
- `is_active = false` (missing from the latest run) is a proxy for sold/withdrawn, not a confirmed sale.
- API returns a limited page of results per city, so this is a sample, not the full market.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # add your RapidAPI key

# offline (no API calls)
python -m ingestion.main --fixture tests/fixtures/sample_response.json
python -m ingestion.main --fixture tests/fixtures/sample_response_price_cut.json

# live (5 API requests) / rebuild from landing files (0 requests)
python -m ingestion.main
python -m ingestion.main --replay

cd zillow_dbt
dbt deps
dbt build --profiles-dir .
dbt docs generate --profiles-dir . && dbt docs serve
```

## Testing

- `pytest`: parsing and idempotent-load tests
- dbt data tests: grain, keys, relationships, accepted values, warn-level quality checks
- dbt unit tests: valuation gap and price-to-rent ratio
- CI (GitHub Actions): ruff, pytest, fixture load, `dbt build` on every PR
