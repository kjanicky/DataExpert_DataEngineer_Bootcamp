"""HTTP client for the Zillow RapidAPI endpoint with timeouts and retries."""
import logging

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import Settings

log = logging.getLogger(__name__)


class ZillowClient:
    def __init__(self, settings: Settings, timeout: int = 30):
        self.url = settings.api_url
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "X-RapidAPI-Key": settings.api_key,
            "X-RapidAPI-Host": settings.api_host,
        })
        retry = Retry(
            total=5,
            backoff_factor=2,
            status_forcelist=[429, 500, 502, 503, 504],
            respect_retry_after_header=True,
            allowed_methods=["GET"],
        )
        self.session.mount("https://", HTTPAdapter(max_retries=retry))

    def search(self, lat: str, lon: str, page: int = 1, radius: int = 50,
               status_type: str = "ForSale", sort: str = "DaysOnZillow") -> dict | None:
        params = {
            "latitude": lat, "longitude": lon, "page": str(page),
            "radius": radius, "status_type": status_type, "sort": sort,
        }
        try:
            r = self.session.get(self.url, params=params, timeout=self.timeout)
            r.raise_for_status()
            return r.json()
        except requests.RequestException as e:
            log.error("Request failed for (%s, %s) page %s: %s", lat, lon, page, e)
            return None
