"""Settings and configuration loading. Fails fast when required env vars are missing."""
import os
from dataclasses import dataclass
from pathlib import Path

import yaml
from dotenv import load_dotenv

load_dotenv()

REQUIRED_VARS = ("RAPIDAPI_KEY", "RAPIDAPI_HOST", "RAPIDAPI_URL")


@dataclass(frozen=True)
class Settings:
    api_key: str
    api_host: str
    api_url: str
    max_pages_per_city: int = 1


def get_db_path() -> str:
    return os.getenv("DUCKDB_PATH", "zillow_dw.duckdb")


def get_settings() -> Settings:
    missing = [v for v in REQUIRED_VARS if not os.getenv(v)]
    if missing:
        raise EnvironmentError(f"Missing env vars: {missing}")
    return Settings(
        api_key=os.environ["RAPIDAPI_KEY"],
        api_host=os.environ["RAPIDAPI_HOST"],
        api_url=os.environ["RAPIDAPI_URL"],
        max_pages_per_city=int(os.getenv("MAX_PAGES_PER_CITY", "1")),
    )


def load_cities(path: str = "config/cities.yml") -> dict:
    return yaml.safe_load(Path(path).read_text())["cities"]
