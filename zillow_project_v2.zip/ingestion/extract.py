"""Pure parsing logic: API response -> raw records. No network, easy to unit test."""
import json
import logging

import pandas as pd

log = logging.getLogger(__name__)


def parse_response(raw: dict | None, city: str, page: int,
                   extracted_at: pd.Timestamp, run_id: str) -> list[dict]:
    if not isinstance(raw, dict) or not isinstance(raw.get("searchResults"), list):
        log.warning("Unexpected response shape for %s page %s", city, page)
        return []

    records = []
    for item in raw["searchResults"]:
        prop = item.get("property") if isinstance(item, dict) else None
        if not isinstance(prop, dict) or prop.get("zpid") is None:
            continue
        records.append({
            "zpid": int(prop["zpid"]),
            "extracted_at": extracted_at,
            "run_id": run_id,
            "searched_city": city,
            "page": page,
            "payload": json.dumps(prop),
        })
    return records
