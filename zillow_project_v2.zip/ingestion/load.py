"""Idempotent load of raw records into DuckDB (fixed schema, JSON payload)."""
import logging

import duckdb
import pandas as pd

log = logging.getLogger(__name__)

DDL = """
create schema if not exists raw;
create table if not exists raw.zillow_listings (
    zpid          bigint      not null,
    extracted_at  timestamptz not null,
    run_id        varchar     not null,
    searched_city varchar     not null,
    page          integer,
    payload       json        not null,
    primary key (zpid, extracted_at)
);
"""


def load_raw(records: list[dict], db_path: str) -> int:
    """Insert records; rows already present (same zpid + extracted_at) are ignored."""
    if not records:
        log.warning("Nothing to load")
        return 0

    df = pd.DataFrame(records)
    # Overlapping search radii can return the same listing twice in one run: keep the first.
    df = df.drop_duplicates(subset=["zpid", "extracted_at"], keep="first")

    with duckdb.connect(db_path) as con:
        con.execute(DDL)
        con.register("batch", df)
        before = con.execute("select count(*) from raw.zillow_listings").fetchone()[0]
        con.execute("""
            insert or ignore into raw.zillow_listings
                (zpid, extracted_at, run_id, searched_city, page, payload)
            select zpid, extracted_at, run_id, searched_city, page, cast(payload as json)
            from batch
        """)
        inserted = con.execute("select count(*) from raw.zillow_listings").fetchone()[0] - before

    log.info("Inserted %s new rows (%s received)", inserted, len(df))
    return inserted
