"""Pipeline entry point.

Modes:
    python -m ingestion.main                       # live: call API, save responses to landing zone, load
    python -m ingestion.main --fixture FILE.json   # offline: load a saved response (tests / CI)
    python -m ingestion.main --replay              # offline: rebuild raw table from data/landing/
"""
import argparse
import json
import logging
import time
import uuid
from pathlib import Path

import pandas as pd

from .client import ZillowClient
from .config import get_db_path, get_settings, load_cities
from .extract import parse_response
from .load import load_raw

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("ingestion")

LANDING_DIR = Path("data/landing")


def run_live() -> list[dict]:
    settings = get_settings()
    client = ZillowClient(settings)
    run_id = str(uuid.uuid4())
    extracted_at = pd.Timestamp.now(tz="UTC")

    landing = LANDING_DIR / run_id
    landing.mkdir(parents=True, exist_ok=True)
    (landing / "_manifest.json").write_text(
        json.dumps({"run_id": run_id, "extracted_at": extracted_at.isoformat()})
    )

    records: list[dict] = []
    for city, coords in load_cities().items():
        for page in range(1, settings.max_pages_per_city + 1):
            resp = client.search(coords["lat"], coords["lon"], page)
            if resp is not None:
                # Save the untouched response first: the warehouse can always be rebuilt from it.
                (landing / f"{city.replace(' ', '_')}__page{page}.json").write_text(json.dumps(resp))
            rows = parse_response(resp, city, page, extracted_at, run_id)
            if not rows:
                break
            records.extend(rows)
            time.sleep(1)

    log.info("Run %s extracted %s records", run_id, len(records))
    return records


def run_replay() -> list[dict]:
    records: list[dict] = []
    for manifest_path in sorted(LANDING_DIR.glob("*/_manifest.json")):
        manifest = json.loads(manifest_path.read_text())
        extracted_at = pd.Timestamp(manifest["extracted_at"])
        for f in sorted(manifest_path.parent.glob("*__page*.json")):
            city, page = f.stem.rsplit("__page", 1)
            records.extend(parse_response(json.loads(f.read_text()), city.replace("_", " "),
                                          int(page), extracted_at, manifest["run_id"]))
    log.info("Replay found %s records in %s", len(records), LANDING_DIR)
    return records


def run_fixture(path: str) -> list[dict]:
    with open(path) as f:
        raw = json.load(f)
    return parse_response(raw, "Fixture City", 1, pd.Timestamp.now(tz="UTC"), f"fixture-{uuid.uuid4()}")


def main() -> None:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--fixture", help="Load a saved API response instead of calling the API")
    group.add_argument("--replay", action="store_true", help="Rebuild raw table from data/landing/")
    args = parser.parse_args()

    if args.fixture:
        records = run_fixture(args.fixture)
    elif args.replay:
        records = run_replay()
    else:
        records = run_live()

    load_raw(records, get_db_path())


if __name__ == "__main__":
    main()
