"""Spend ONE API request to save a real response as a test fixture.

Run from repo root:  python -m scripts.capture_fixture
"""
import json
from pathlib import Path

from ingestion.client import ZillowClient
from ingestion.config import get_settings

if __name__ == "__main__":
    resp = ZillowClient(get_settings()).search("40.7128", "-74.0060", page=1)
    out = Path("tests/fixtures/real_response.json")
    out.write_text(json.dumps(resp, indent=2))
    print(f"Saved {out}")
