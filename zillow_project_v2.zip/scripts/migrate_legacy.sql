-- One-off migration: move the v1 flattened table into the raw schema as a frozen legacy source.
-- 1) Close all other connections and back up zillow_dw.duckdb first.
-- 2) Run:  duckdb zillow_dw.duckdb < scripts/migrate_legacy.sql

create schema if not exists raw;

create table raw.zillow_listings_legacy as
select * from main.raw_zillow_listings;

-- Must be equal before you drop anything
select (select count(*) from main.raw_zillow_listings)  as old_rows,
       (select count(*) from raw.zillow_listings_legacy) as new_rows;

-- Portable typed archive (create the data/archive folder first)
-- copy raw.zillow_listings_legacy to 'data/archive/zillow_listings_legacy.parquet' (format parquet);

-- Uncomment after verifying the counts above:
-- drop table main.raw_zillow_listings;
