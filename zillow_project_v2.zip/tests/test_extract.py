import json
from pathlib import Path

import pandas as pd

from ingestion.extract import parse_response

TS = pd.Timestamp("2026-01-01", tz="UTC")
FIXTURE = json.loads(Path("tests/fixtures/sample_response.json").read_text())


def test_fixture_parses_only_valid_properties():
    rows = parse_response(FIXTURE, "New York", 1, TS, "run-1")
    assert [r["zpid"] for r in rows] == [1001, 1002]


def test_record_has_fixed_schema():
    row = parse_response(FIXTURE, "New York", 1, TS, "run-1")[0]
    assert set(row) == {"zpid", "extracted_at", "run_id", "searched_city", "page", "payload"}
    assert json.loads(row["payload"])["price"]["value"] == 750000


def test_bad_shapes_return_empty():
    assert parse_response(None, "X", 1, TS, "r") == []
    assert parse_response({"oops": 1}, "X", 1, TS, "r") == []
    assert parse_response({"searchResults": "not a list"}, "X", 1, TS, "r") == []
