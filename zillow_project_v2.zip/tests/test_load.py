import json
from pathlib import Path

import duckdb
import pandas as pd

from ingestion.extract import parse_response
from ingestion.load import load_raw

FIXTURE = json.loads(Path("tests/fixtures/sample_response.json").read_text())


def test_load_is_idempotent(tmp_path):
    db = str(tmp_path / "test.duckdb")
    ts = pd.Timestamp("2026-01-01", tz="UTC")
    rows = parse_response(FIXTURE, "New York", 1, ts, "run-1")

    assert load_raw(rows, db) == 2
    assert load_raw(rows, db) == 0  # same snapshot again -> nothing inserted

    with duckdb.connect(db) as con:
        assert con.execute("select count(*) from raw.zillow_listings").fetchone()[0] == 2


def test_new_snapshot_is_appended(tmp_path):
    db = str(tmp_path / "test.duckdb")
    for day in ("2026-01-01", "2026-01-02"):
        load_raw(parse_response(FIXTURE, "New York", 1, pd.Timestamp(day, tz="UTC"), day), db)
    with duckdb.connect(db) as con:
        assert con.execute("select count(*) from raw.zillow_listings").fetchone()[0] == 4


def test_payload_is_queryable_json(tmp_path):
    db = str(tmp_path / "test.duckdb")
    load_raw(parse_response(FIXTURE, "New York", 1, pd.Timestamp("2026-01-01", tz="UTC"), "r"), db)
    with duckdb.connect(db) as con:
        price = con.execute(
            "select payload->>'$.price.value' from raw.zillow_listings where zpid = 1001"
        ).fetchone()[0]
    assert price == "750000"
