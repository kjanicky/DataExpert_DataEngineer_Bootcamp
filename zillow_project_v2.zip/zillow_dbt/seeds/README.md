Put `mean_median_income_US.csv` here (columns used: Zip_Code, Median, Mean, State_ab, City).
